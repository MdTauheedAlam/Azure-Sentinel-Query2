from datetime import datetime
import unittest
import importlib
from unittest.mock import ANY, patch

from shared_code.models.oat import OATDetectionResult

MOCK_TOKEN = 'eyJ0eXAiOiJKV1QiLCJhbGciOiJSUzI1NiJ9.eyJjaWQiOiI4Yzg0MDg3My0zMTQ1LTRlNWEtYWVkZS0wMjE2NzljZTIzZDgiLCJjcGlkIjoic3ZwIiwicHBpZCI6ImN1cyIsIml0IjoxNjE1ODgwNzg1LCJ1aWQiOiJteGRyXzRiOTE0ZTYyQG1kci50cmVuZG1pY3JvLmNvbSIsInBsIjoiIiwiZXQiOjE2NDc0MTY3ODV9.V2SZHU85H8K55DpzHemToIr55kWaOQMWVV5CdImKGSePpntapsqW1tIEKbpuAemMyicKUNM1ewwC8fwJNZl7bW8puugYg92ynkXWGqKQiureKwCZM7Kfp-L-4LUvTsLF_DVDCECsptJNKkFZANryKqOFdEmiowmwRaqkoHkDT5qF_xCRnGx5nfzof8Nb_ey6PMQuH2mdOJRtfHkW4m9HZ3C-Ab2kuizD3J-BkOWGmn642hv1C9ClNp5IesMF_bhT21rIO4jkSW6GPz5nb9cEFMuepJK7F8177BGNh8LfJzfmeGgX141QGje4LdSXGq0eUlXzFxg0hMAXCS35a6bQeKGTh5Dfnxt4iSGLq47_ddiSEBifWuMiLyjAbxxV9QiF-Bee9q_gZdsczJCO9c7I4eoW2acqTOva-Ts0VVenXrp0g5qdBtZgoFOG4BZj_dnzla3fUa60rFlsE6_4VbSv0-mV7yZirRrB7cxwb2Gqzw_7dFCdKEg3Eax5ljT882FtJeUFGH1cOyUf-Uj4YlfByDSQyvPtqlyNoHX66Jz6yauWuJbL9n1cN_ZseKdf3gQtRRenNTLZG84dATj-WKYcp3w-KJtpCEDxLFbZFwb5Te7NlxrItHk0wPaG0opxbwDUwZTJ7yUhYORgD8U4fW0rpiC3Si5a8BV06IPf8vVZst4'
MOCK_XDR_HOST_URL = 'https://test.host.com'
MOCK_TRACE_ID = '645f4f62-e3e4-45a6-a853-af64cfd8d3e5'
MOCK_TASK_ID = '35fd435a-5baa-4de5-b5bd-9893b5aaa3cb'

ENV = {"apiTokens": MOCK_TOKEN, "xdrHostUrl": MOCK_XDR_HOST_URL}
HTTP_HEADER = {
    'Authorization': f"Bearer {MOCK_TOKEN}",
    'Content-Type': 'application/json;charset=utf-8',
    'x-trace-id': MOCK_TRACE_ID,
    'x-task-id': MOCK_TASK_ID,
    'User-Agent': 'TMXDRSentinelAddon/1.0.0',
}


class TestOATService(unittest.TestCase):
    def setUp(self):
        patcher = patch.dict('os.environ', ENV)
        patcher.start()
        patch(
            'shared_code.trace_utils.trace.trace_manager.trace_id', MOCK_TRACE_ID
        ).start()
        patch(
            'shared_code.trace_utils.trace.trace_manager.task_id', MOCK_TASK_ID
        ).start()
        self.oat_service = importlib.reload(
            importlib.import_module('shared_code.services.oat_service')
        )
        self.addCleanup(patcher.stop)
        super().setUp()

    @patch('shared_code.services.oat_service.requests')
    def test_get_oat_list_success(self, requests):
        query_params = {
            'start': 1626776019,
            'end': 1626778019,
            'size': 10,
        }

        url = f"{MOCK_XDR_HOST_URL}/v2.0/xdr/oat/detections"
        requests.get.return_value.json.return_value = {
            'data': {
                'totalCount': 1,
                'detections': [{'uuid': '43391b37-056d-4fd5-9df7-40cf3194f9cd'}],
                'searchApiPostData': [
                    {'query': 'uuid:"43391b37-056d-4fd5-9df7-40cf3194f9cd"'}
                ],
            }
        }
        expect = OATDetectionResult(
            total_count=1,
            detections=[{'uuid': '43391b37-056d-4fd5-9df7-40cf3194f9cd'}],
            search_api_post_data=[
                {'query': 'uuid:"43391b37-056d-4fd5-9df7-40cf3194f9cd"'}
            ],
        )

        result = self.oat_service.get_oat_list(
            MOCK_TOKEN,
            datetime.fromtimestamp(1626776019),
            datetime.fromtimestamp(1626778019),
            size=10,
        )

        requests.get.assert_called_with(url, headers=HTTP_HEADER, params=query_params)
        self.assertEqual(result, expect)

    @patch('shared_code.services.oat_service.requests')
    def test_get_search_data_success(self, requests):
        mock_oat_post_data = {'query': 'uuid:"43391b37-056d-4fd5-9df7-40cf3194f9cd"'}
        url = f"{MOCK_XDR_HOST_URL}/v2.0/xdr/search/data"
        requests.post.return_value.json.return_value = {
            'data': {'logs': [{'uuid': '43391b37-056d-4fd5-9df7-40cf3194f9cd'}]}
        }

        result = self.oat_service.get_search_data(MOCK_TOKEN, mock_oat_post_data)

        requests.post.assert_called_with(
            url, headers=HTTP_HEADER, json=mock_oat_post_data
        )
        self.assertEqual(result, [{'uuid': '43391b37-056d-4fd5-9df7-40cf3194f9cd'}])

