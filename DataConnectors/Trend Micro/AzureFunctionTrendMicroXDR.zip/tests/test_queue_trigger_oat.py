import json
from unittest import TestCase
from unittest.mock import ANY, patch, MagicMock
import importlib

from requests.models import HTTPError

from shared_code.models.oat import OATQueueMessage

MOCK_TOKEN = "eyJ0eXAiOiJKV1QiLCJhbGciOiJSUzI1NiJ9.eyJjaWQiOiI4Yzg0MDg3My0zMTQ1LTRlNWEtYWVkZS0wMjE2NzljZTIzZDgiLCJjcGlkIjoic3ZwIiwicHBpZCI6ImN1cyIsIml0IjoxNjE1ODgwNzg1LCJ1aWQiOiJteGRyXzRiOTE0ZTYyQG1kci50cmVuZG1pY3JvLmNvbSIsInBsIjoiIiwiZXQiOjE2NDc0MTY3ODV9.V2SZHU85H8K55DpzHemToIr55kWaOQMWVV5CdImKGSePpntapsqW1tIEKbpuAemMyicKUNM1ewwC8fwJNZl7bW8puugYg92ynkXWGqKQiureKwCZM7Kfp-L-4LUvTsLF_DVDCECsptJNKkFZANryKqOFdEmiowmwRaqkoHkDT5qF_xCRnGx5nfzof8Nb_ey6PMQuH2mdOJRtfHkW4m9HZ3C-Ab2kuizD3J-BkOWGmn642hv1C9ClNp5IesMF_bhT21rIO4jkSW6GPz5nb9cEFMuepJK7F8177BGNh8LfJzfmeGgX141QGje4LdSXGq0eUlXzFxg0hMAXCS35a6bQeKGTh5Dfnxt4iSGLq47_ddiSEBifWuMiLyjAbxxV9QiF-Bee9q_gZdsczJCO9c7I4eoW2acqTOva-Ts0VVenXrp0g5qdBtZgoFOG4BZj_dnzla3fUa60rFlsE6_4VbSv0-mV7yZirRrB7cxOAT2Gqzw_7dFCdKEg3Eax5ljT882FtJeUFGH1cOyUf-Uj4YlfByDSQyvPtqlyNoHX66Jz6yauWuJbL9n1cN_ZseKdf3gQtRRenNTLZG84dATj-WKYcp3w-KJtpCEDxLFbZFOAT5Te7NlxrItHk0wPaG0opxbwDUwZTJ7yUhYORgD8U4fW0rpiC3Si5a8BV06IPf8vVZst4"
ENV = {
    "apiTokens": MOCK_TOKEN,
    "regionCode": "uae",
    "AzureWebJobsStorage": "fakeconnection",
    "workspaceId": "6a183caf-a148-4a43-845a-db6f4e645bfb",
    "workspaceKey": "m4qj7Y+sgW1hTi66m07/++fkGl38Dq46DwmDwOdx/vaWU86N5x8NicNmBeXXmgSbosTIfpL+AEuLigwQhidVPw==",
}
MOCK_CLP_ID = "8c840873-3145-4e5a-aede-021679ce23d8"


class TestQueueTriggerOAT(TestCase):
    def setUp(self):
        patcher = patch.dict('os.environ', ENV)
        patcher.start()
        self.queue_trigger_oat = importlib.reload(
            importlib.import_module('queue_trigger_oat')
        )
        self.addCleanup(patcher.stop)
        super().setUp()

    @patch('queue_trigger_oat.utils.find_token_by_clp')
    @patch('queue_trigger_oat.get_search_data')
    @patch('queue_trigger_oat.LogAnalytics')
    def test_queue_trigger_oat_success(
        self, log_analytics, get_search_data, find_token_by_clp
    ):
        log_analytics_instance = log_analytics()
        msg = MagicMock()
        mock_oat_record = {'uuid': 'test_01'}
        post_data = {'query': 'test_01 and test_02'}
        result = OATQueueMessage(
            clp_id=MOCK_CLP_ID,
            detections=[mock_oat_record],
            post_data=post_data,
        )
        msg.get_json.return_value = result.dict()
        find_token_by_clp.return_value = MOCK_TOKEN
        mock_oat_raw_log = {'uuid': 'test_01', 'fake_data': 'data'}
        get_search_data.return_value = [mock_oat_raw_log]
        trasformed_logs = dict(**mock_oat_record)
        trasformed_logs.update(mock_oat_raw_log)
        trasformed_logs.update(
            {'xdrCustomerId': '8c840873-3145-4e5a-aede-021679ce23d8'}
        )

        self.queue_trigger_oat.main(msg)

        find_token_by_clp.assert_called_with(MOCK_CLP_ID, ANY)
        get_search_data.assert_called_with(MOCK_TOKEN, post_data)
        log_analytics_instance.post_data.assert_called_with([trasformed_logs])

    @patch('queue_trigger_oat.utils.find_token_by_clp')
    @patch('queue_trigger_oat.get_search_data')
    @patch('queue_trigger_oat.LogAnalytics')
    def test_queue_trigger_oat_failed_throw_exception(
        self, log_analytics, get_search_data, find_token_by_clp
    ):
        log_analytics_instance = log_analytics()
        msg = MagicMock()
        mock_oat_record = {'uuid': 'test_01'}
        post_data = {'query': 'test_01 and test_02'}
        result = OATQueueMessage(
            clp_id=MOCK_CLP_ID,
            detections=[mock_oat_record],
            post_data=post_data,
        )
        msg.get_json.return_value = result.dict()
        find_token_by_clp.return_value = MOCK_TOKEN
        get_search_data.side_effect = HTTPError()

        with self.assertRaises(HTTPError):
            self.queue_trigger_oat.main(msg)

        find_token_by_clp.assert_called_with(MOCK_CLP_ID, ANY)
        get_search_data.assert_called_with(MOCK_TOKEN, post_data)
        log_analytics_instance.post_data.assert_not_called()
