import json
from unittest import TestCase
from unittest.mock import ANY, patch, MagicMock
import os
from shared_code import transform_utils




class TestTransformUtils(TestCase):
    pwd = os.path.dirname(__file__)
    xdr_customer_id = '68960c94-9be6-4343-a4ca-6408de7aa331'
    workbench_id = 'WB-9002-20210426-00021'
    task_id = '8cd37222-fc75-4f0c-92c0-d92280d3342d'
    task_name = 'WB-9002-20210426-00021-PTE_RCA-ef43e56e'

    def test_rca_task_success(self):
        with open(f"{self.pwd}/data/prca_task_source.json") as f:
            rca_task_source = json.load(f)

        with open(f"{self.pwd}/data/prca_task_expect.json") as f:
            rca_task_expect = json.load(f)

        result = transform_utils.transform_rca_task(self.xdr_customer_id, self.workbench_id, rca_task_source['data'][0])
        self.assertEqual(result, rca_task_expect[0])

    def test_rca_result_success(self):
        with open(f"{self.pwd}/data/prca_result_source.json") as f:
            rca_result_source = json.load(f)

        with open(f"{self.pwd}/data/prca_result_expect.json") as f:
            rca_result_expect = json.load(f)

        target_info = {
            'xdrCustomerID': self.xdr_customer_id,
            'taskId': self.task_id,
            'taskName': self.task_name,
            'agentEntity': {
                "hostname": "",
                "guid": "35FA11DA-A24E-40CF-8B56-BAF8828CC15E",
                "ip": [
                    ""
                ]
            },
            'workbenchId': self.workbench_id
        }

        result = transform_utils.transform_rca_result(target_info, rca_result_source['data'])
        self.assertEqual(result, rca_result_expect)
        
    def test_transform_oat_log(self):
        clp_id = "c58428c0-05b6-4990-9102-140e376a1114"
        
        with open(f"{self.pwd}/data/oat_result.json") as f:
            data = json.load(f)['data']
        with open(f"{self.pwd}/data/xdl_search_result.json") as f:
            raw_logs = json.load(f)['data']['logs']
        detections = data['detections']
        ## def _transfrom_logs(clp_id, detections, raw_logs):
        maps = {detection['uuid']: detection for detection in detections}
        for log in raw_logs:
            if log['uuid'] in maps:
                maps[log['uuid']].update(log)

        log = [transform_utils.transform_oat_log(clp_id, log) for log in maps.values()]
        
        print(f'{json.dumps(log)}')